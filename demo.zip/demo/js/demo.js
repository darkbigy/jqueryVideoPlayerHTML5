function modifyPlayer()
{
	$('#demo1Video').html('<video controls id="my_video">'
                         +'<source src="./video/oceans-clip_HD.ogv" type="video/ogg" data-version="SD" />'
                         +'<source src="./video/oceans-clip_HD.ogv" type="video/ogg" data-version="HD" />'
                         +'<track kind="subtitles" label="English" srclang="en" src="sample_EN.srt" />'
                         +'<track kind="subtitles" label="Francais" srclang="fr" src="sample_FR.srt" />'
                         +'</video>');
    $("#my_video").jQueryVideoHTML5(generateNewSettings());
}

      
function autoCheck(element)
{
	$('input:checkbox', element.parent().next())[0].checked = true;
}          

function generateNewSettings()
{
	var newSettings = new Object();
    var checkedOption = $('input:checkbox');
    checkedOption.each(function(i){
   		if (this.checked)
        { 
        	var prop = $(this).parent().prev().children();
            var id = prop.attr('id');
            if (id == 'defaultVolume' || id == 'skipStep' || id == 'volumeStep')
            {
            	prop = parseFloat(prop.val());
            }
            else if (prop.val() == 'false')
            {
            	prop = false;
            }
            else if (prop.val() == 'true')
            {
          	 	prop = true;
            }
            else
            {
            	prop = prop.val();
            }	
            newSettings[id] = prop;
        }
   });
   return newSettings;
}